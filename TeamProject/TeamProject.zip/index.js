$(document).ready(function(){
	$('#mobile_hidden_list').hide();

	$('#mobile_menu_icon').on('click', function(){
    	$('#mobile_hidden_list').toggle();
    	return false;
    });
});